package com.example.springday01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springday01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
