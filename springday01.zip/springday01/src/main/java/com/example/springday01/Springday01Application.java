package com.example.springday01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springday01Application {

	public static void main(String[] args) {
		SpringApplication.run(Springday01Application.class, args);
	}

}
